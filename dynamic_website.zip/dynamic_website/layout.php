<?php
function drawheader(){
	
echo " <div id=\"header\">
         <div id=\"logo\"> 
   <h1>
   <a href=\"#\">Dynamic Website</a>
   </h1> 
	<h2><a href=\"#\">Simple dynamic website for us<em>!</em></a></h2>
  </div>
	<div id=\"menu\">
		<ul>
			<li><a href=\"#\">Home</a></li>
			<li><a href=\"#\">Blogs</a></li>
			<li><a href=\"#\">Photos</a></li>
			<li><a href=\"#\">About</a></li>
			<li><a href=\"#\">Contact</a></li>
		</ul>
	</div>	

</div>";
}

function drawmain(){
	
echo "   <div class=\"back\">
		 <div class=\"top\">
			<div class=\"bottom\">
			<h2>Welcome To Our Website</h2>
			<h4><a href=\"#\">METAMORPHOSIS DESIGN</a></h4>
			<p>This website template is released under  a Creative Commons Attribution 2.5 License</p>
			    <p>We request you retain the full copyright notice below including the link to www.metamorphozis.com.<br />
			      This not only gives respect to the large amount of time given freely by the developers 
			      but also helps build interest, traffic and use of our free and paid designs. If you cannot (for good 
			      reason) retain the full copyright we request you at least leave in place the 
			      Website Templates line, with Website Templates  linked to www.metamorphozis.com. If you refuse 
			      to include even this then support may be affected.<br />
                <br />
			      You are allowed to use this design only if you agree to the following conditions:<br />
			      - You cannot remove copyright notice from this design without our permission.<br />
			      - If you modify this design it still should contain copyright because it is based on our work.<br />
			      - You may copy, distribute, modify, etc. this template as long as link to our website remains untouched.<br />
			      For support visit http://www.metamorphozis.com/contact/contact.php<br />
  <br />
			      The Metamorphosis Design : 2011 </p>
			<p class=\"date\"><img src=\"images/comment.gif\" alt=\"\" /> <a href=\"#\">Comments(2)</a> <img src=\"images/timeicon.gif\" alt=\"\" /> 21.02.</p> 
			</div>
			</div>
			</div>
			
			 <div><img src=\"images/spacer.gif\" width=\"1\" height=\"20px\" alt=\"\" /></div>"; 
			 
}

function drawsubmain(){
echo "<div><img src=\"images/spacer.gif\" width=\"1\" height=\"20px\" alt=\"\" /></div>
		<div class=\"back\">
		   <div class=\"top\">
			<div class=\"bottom\">
			<h4><a href=\"#\">Web Design Starter's Guide</a></h4>
	<ol>
				<li><a href=\"#\">More Free Website Templates</a></li>
	<li><a href=\"#\">Flash Templates</a></li>
                <li><a href=\"#\">Top Hosting Providers</a></li>
                <li><a href=\"#\">Support For Free Website Templates</a></li>
             
		  </ol>
	<p class=\"date\"><img src=\"images/comment.gif\" alt=\"\" /> <a href=\"#\">Comments(34)</a> <img src=\"images/timeicon.gif\" alt=\"\" /> 22.04.</p> 			</div>
			</div>
			</div>
			<div><img src=\"images/spacer.gif\" width=\"1\" height=\"20px\" alt=\"\" /></div>
		<div class=\"back\">
		   <div class=\"top\">
			<div class=\"bottom\">
			<h4><a href=\"#\">FREE WEBSITE TEMPLATES</a></h4>
			<p>Consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat.</p>
			<p>Sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autemr in hendrerit in vulputate velit esse molestie consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat...</p>
			<p class=\"date\"><img src=\"images/comment.gif\" alt=\"\" /> <a href=\"#\">Comments(8)</a> <img src=\"images/timeicon.gif\" alt=\"\" /> 13.46.</p>			 
	             </div>
	           </div>
			</div>
			<div><img src=\"images/spacer.gif\" width=\"1\" height=\"20px\" alt=\"\" /></div> ";

}

function drawsidebar(){
echo " <div id=\"sidebar2\" class=\"sidebar\">
		    <div class=\"r1\">
				<h2>Categories</h2>
				<ul>
					<li><a href=\"#\">Aliquam libero</a></li>
					<li><a href=\"#\">Consectetuer elit</a></li>
					<li><a href=\"#\">Metus pellentesque</a></li>
					<li><a href=\"#\">Suspendisse mauris</a></li>
					<li><a href=\"#\">Urnanet molestie semper</a></li>
					<li><a href=\"#\">Proin orci porttitor</a></li>
				</ul>
		      </div>
			  <div><img src=\"images/spacer.gif\" width=\"1\" height=\"20px\" alt=\"\" /></div>
			  
              
              <div class=\"r1\">
				<h2>Archives</h2>
				<ul>
					<li><a href=\"#\">September</a> (23)</li>
					<li><a href=\"#\">August</a> (31)</li>
					<li><a href=\"#\">July</a> (31)</li>
					<li><a href=\"#\">June</a> (30)</li>
					<li><a href=\"#\">May</a> (31)</li>
				</ul>
		      </div>
			  <div><img src=\"images/spacer.gif\" width=\"1\" height=\"20px\" alt=\"\" /></div>
			  <div class=\"r1\">
				<h2>Lorem ipsum dolor </h2>
				<ul>
					<li><a href=\"#\">Aliquam libero</a></li>
					<li><a href=\"#\">Consectetuer elit</a></li>
					<li><a href=\"#\">Metus pellentesque</a></li>
					<li><a href=\"#\">Suspendisse mauris</a></li>
					<li><a href=\"#\">Urnanet molestie semper</a></li>
					<li><a href=\"#\">Proin orci porttitor</a></li>
				</ul>
		      </div>
	</div>";

}


function drawfooter(){
echo "<div id=\"footer\">
	 <p>SAMPLE DYNAMIC WEBSITE (2011) by JAYSON. </p> 
</div> ";
}

?>